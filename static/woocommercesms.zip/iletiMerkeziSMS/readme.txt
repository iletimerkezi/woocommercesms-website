=== İleti Merkezi SMS Eklentisi ===
Contributors: iletimerkezi
Tags: order, order SMS, SMS order , notification, order notification, sell notification, notification, sms, iletimerkezi , woocommerce order, woocommerce order notification,
Requires at least: 3.5
Tested up to: 4.0
Stable tag: trunk
License: GPLv2
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A plugin for sending sms notification after placing orders using woocommerce

== Description ==

This is a WooCommerce add-on. By Using this plugin admin and buyer can get notification about their order via sms using iletimerkezi.com .

The İleti Merkezi SMS plugin for WordPress is very useful, when you want to get notified via SMS after placing an order. Buyer and seller both can get SMS notification after an order is placed. SMS notification options can be customized in the admin panel very easily.

= Key Features =

* Very easy to install
* Very easy to customize
* Admin can get Order SMS notifications
* Buyer can get order sms notifications
* Customizable SMS text
* Send Order details ( order no, order status ) in SMS text
* Extended Settings Option
* Works with WooCommerce 2.0+
* All version of WordPress 3.0+ supported


== Changelog ==

= 1.0.0 =
Initial version released

== Upgrade Notice ==

Noting here
