<?php

// If uninstall is not called from WordPress, exit
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$options = [ 
	'imn_api_key',
	'imn_api_hash',
	'imn_api_sender',
	'imn_admin_phone',
	'imn_webhook',
	'imn_default_country_code',
	'imn_debug',
	'imn_iys',
	'imn_iys_list',
	'imn_wc_new_customer_order_note_enabled',
	'imn_wc_new_order_for_admin'
];

if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
	foreach ( wc_get_order_statuses() as $status => $title ) {
		$slug = 'imn_wc_' . str_replace( 'wc-', '', $status );
		delete_option( $slug );
		delete_option( $slug . '_enabled' );
	}
}

if ( is_plugin_active( 'contact-form-7/wp-contact-form-7.php' ) ) {
	foreach ( imn_view_cf7_form_data() as $form ) {
		delete_option( 'imn_cf7_form_' . $form['id'] . '_customer_gsm' );
		delete_option( 'imn_cf7_form_' . $form['id'] . '_customer_template' );
		delete_option( 'imn_cf7_form_' . $form['id'] . '_admin_template' );
	}
}

if ( is_plugin_active( 'booked/booked.php' ) ) {
	delete_option( 'imn_booked_calendar_users_gsm_field' );
	delete_option( 'imn_booked_new_appointment_created_template' );
	delete_option( 'imn_booked_appointment_approved_template' );
	delete_option( 'imn_booked_appointment_cancelled_template' );
	delete_option( 'imn_booked_appointment_reminder_buffer' );
	delete_option( 'imn_booked_appointment_reminder_template' );

	foreach ( imn_model_booked_get_calendars() as $calendar ) {
		delete_option( 'imn_booked_calendar_' . $calendar->term_id . '_users_gsm_field' );
	}
}

// Delete custom tables (if any)
global $wpdb;

$table_reports = $wpdb->prefix . 'imn_reports';
$table_integration = $wpdb->prefix . 'imn_integrations';
$table_integration = $wpdb->prefix . 'imn_logs';

$wpdb->query( "DROP TABLE IF EXISTS {$table_reports}" );
$wpdb->query( "DROP TABLE IF EXISTS {$table_integration}" );