<?php

if ( ! defined( 'IMN_VERSION' ) ) {
	define( 'IMN_VERSION', '1.0.0' );
}

if ( ! defined( 'IMN_SLUG' ) ) {
	define( 'IMN_SLUG', 'im-settings' );
}

if ( ! defined( 'IMN_API_OPTIONS' ) ) {
	define( 'IMN_API_OPTIONS', 'imn-api-settings' );
}

if ( ! defined( 'IMN_WC_OPTIONS' ) ) {
	define( 'IMN_WC_OPTIONS', 'imn-wc-settings' );
}

if ( ! defined( 'IMN_CF7_OPTIONS' ) ) {
	define( 'IMN_CF7_OPTIONS', 'imn-cf7-settings' );
}

if ( ! defined( 'IMN_BOOKED_OPTIONS' ) ) {
	define( 'IMN_BOOKED_OPTIONS', 'imn-booked-settings' );
}

if ( ! defined( 'IMN_PLUGIN_DIR' ) ) {
	define( 'IMN_PLUGIN_DIR', plugin_dir_path( __FILE__ ) . '../' );
}