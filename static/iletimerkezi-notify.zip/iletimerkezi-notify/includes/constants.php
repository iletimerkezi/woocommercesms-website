<?php

if ( ! defined( 'IMN_VERSION' ) ) {
	define( 'IMN_VERSION', '1.0.0' );
}

if ( ! defined( 'IMN_SLUG' ) ) {
	define( 'IMN_SLUG', 'im-settings' );
}

if ( ! defined( 'IMN_OPTIONS' ) ) {
	define( 'IMN_OPTIONS', 'im-settings' );
}

if ( ! defined( 'IMN_PLUGIN_DIR' ) ) {
	define( 'IMN_PLUGIN_DIR', plugin_dir_path( __FILE__ ) . '../' );
}