<?php
function imn_options() {

    $options = [
        'imn_api_key',
        'imn_api_hash',
        'imn_api_sender',
        'imn_admin_phone',
        'imn_webhook',
        'imn_default_country_code',
        'imn_debug',
        'imn_iys',
        'imn_iys_list',
        'imn_wc_new_customer_order_note_enabled',
        'imn_wc_new_order_for_admin',
        'imn_wc_new_order_for_admin_enabled'
    ];

    if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
        foreach ( wc_get_order_statuses() as $status => $title ) {
            $slug = 'imn_wc_' . str_replace( 'wc-', '', $status );
            $options += [
                $slug,
                $slug . '_enabled'
            ];
        }
    }

    if ( is_plugin_active( 'contact-form-7/wp-contact-form-7.php' ) ) {
        foreach ( imn_model_cf7_get_form_data() as $form ) {
            $options += [
                'imn_cf7_form_' . $form['id'] . '_customer_gsm',
                'imn_cf7_form_' . $form['id'] . '_customer_template',
                'imn_cf7_form_' . $form['id'] . '_admin_template'
            ];
        }
    }

    if ( is_plugin_active( 'booked/booked.php' ) ) {

        $options += [
            'imn_booked_calendar_users_gsm_field',
            'imn_booked_new_appointment_created_template',
            'imn_booked_appointment_approved_template',
            'imn_booked_appointment_cancelled_template',
            'imn_booked_appointment_reminder_buffer',
            'imn_booked_appointment_reminder_template'
        ];

        foreach ( imn_model_booked_get_calendars() as $calendar ) {
            $options += ['imn_booked_calendar_' . $calendar->term_id . '_users_gsm_field'];
        }
    }

    return $options;
}