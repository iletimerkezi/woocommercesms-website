<?php
if ( ! defined( 'IMN_CUSTOM_INTEGRATION' ) ) {
	define( 'IMN_CUSTOM_INTEGRATION', true );
}