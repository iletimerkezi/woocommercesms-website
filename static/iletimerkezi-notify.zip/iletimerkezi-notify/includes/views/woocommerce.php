<?php

function imn_view_wc_tab() {

	echo '<form method="post" action="options.php">';
	settings_fields( IMN_WC_OPTIONS );
	do_settings_sections( IMN_WC_OPTIONS );
	submit_button();
	echo '</form>';
}

function imn_view_woocommerce_fields() {

	add_settings_section(
		'imn_wc_settings',
		__( 'Woocommerce Settings', 'iletimerkezi-notify' ),
		function () {
			?>
		<p class="description">
			<?php
				printf(
					__(
						'You can set the message texts to be sent in order change. The variables you can use in the message are listed below. You can also use the information that the plugins you use add to the metadata of your order, or you can improve the variables here with the hooks we provide. For more detailed information, see %sdocumentation%s.',
						'iletimerkezi-notify'
					),
					'<a href="https://www.woocommercesms.com">',
					'</a>'
				);
			?>
			<br />
			<br />
			<code>[order_id]</code>
			<code>[first_name]</code>
			<code>[last_name]</code>
			<code>[email]</code>
			<code>[phone]</code>
			<code>[total]</code>
		</p>
		<br />
		<hr />
		<br />
		<?php
		},
		IMN_WC_OPTIONS
	);

	add_settings_field(
		'imn_wc_new_customer_order_note_enabled',
		__( 'Send order notes to customer', 'iletimerkezi-notify' ),
		function () {
			?>
		<input type="checkbox" name="imn_wc_new_customer_order_note_enabled" value="1" <?php checked( 1, get_option( 'imn_wc_new_customer_order_note_enabled' ), true ); ?>>
		<?php
		},
		IMN_WC_OPTIONS,
		'imn_wc_settings',
		[ 'id' => 'imn_wc_new_customer_order_note_enabled' ]
	);

	register_setting( IMN_WC_OPTIONS, 'imn_wc_new_customer_order_note_enabled' );

	add_settings_field(
		'imn_wc_new_order_for_admin',
		__( 'New Order For Admin', 'iletimerkezi-notify' ),
		'imn_view_woocommerce_body_callback',
		IMN_WC_OPTIONS,
		'imn_wc_settings',
		[ 'id' => 'imn_wc_new_order_for_admin' ]
	);

	register_setting( IMN_WC_OPTIONS, 'imn_wc_new_order_for_admin' );
	register_setting( IMN_WC_OPTIONS, 'imn_wc_new_order_for_admin_enabled' );

	foreach ( wc_get_order_statuses() as $status => $title ) {
		$slug = 'imn_wc_' . str_replace( 'wc-', '', $status );

		add_settings_field(
			$slug,
			$title,
			'imn_view_woocommerce_body_callback',
			IMN_WC_OPTIONS,
			'imn_wc_settings',
			[ 'id' => $slug ]
		);

		register_setting( IMN_WC_OPTIONS, $slug );
		register_setting( IMN_WC_OPTIONS, $slug . '_enabled' );
	}
}

function imn_view_woocommerce_body_callback( $args ) {
	$id = $args['id'];
	$body = get_option( $id );
	$status = get_option( $id . '_enabled' );
	?>
	<textarea class="regular-text" name="<?php echo $id; ?>" rows="5"
		cols="50"><?php echo esc_textarea( $body ); ?></textarea>
	<br>
	<input type="checkbox" name="<?php echo $id; ?>_enabled" value="1" <?php echo checked( 1, $status, false ) ?>> <?php echo __( 'Enable', 'iletimerkezi-notify' ); ?>
<?php
}