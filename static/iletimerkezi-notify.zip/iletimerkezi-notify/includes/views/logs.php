<?php

function imn_view_logs_tab() {

	$logs = new IMN_Table_Logs();
	$logs->prepare_items();
	?>
	<div>
		<h2>
			<?php echo __( 'Logs', 'iletimerkezi-notify' ); ?>
		</h2>
		<p></p>
		<?php $logs->display(); ?>
	</div>
	<?php
}