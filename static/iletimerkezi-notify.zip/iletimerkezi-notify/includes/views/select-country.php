<?php

function imn_view_select_country( $field ) {

	$countries = json_decode(
		file_get_contents( IMN_PLUGIN_DIR . 'assets/country-codes.json' ),
		true
	);

	$options = '';
	foreach ( $countries as $country ) {
		$options .= sprintf(
			'<option value="%s" %s>%s</option>',
			$country['dial_code'],
			selected( $country['dial_code'], get_option( $field['id'] ), false ),
			$country['name']
		);
	}

	return '<select class="regular-text" name="' . $field['id'] . '">' . $options . '</select>';
}