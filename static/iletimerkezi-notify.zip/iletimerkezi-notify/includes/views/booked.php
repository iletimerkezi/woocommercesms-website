<?php

function imn_view_booked_tab() {

	echo '<form method="post" action="options.php">';
	settings_fields( IMN_BOOKED_OPTIONS );
	do_settings_sections( IMN_SLUG );
	submit_button();
	echo '</form>';
}

function imn_view_booked_fields() {

	add_settings_section(
		'imn_booked_settings',
		__( 'Booked Settings', 'iletimerkezi-notify' ),
		function () {
			?>
		<p class="description">
			<?php
				_e( 'It allows you to send SMS according to the actions that occur as a result of the appointment. If you leave the message text fields blank, the SMS will not be sent.', 'iletimerkezi-notify' );
				?>
			<br />
			<br />
			<code>[id]</code>
			<code>[name]</code>
			<code>[email]</code>
			<code>[title]</code>
			<code>[calendar]</code>
			<code>[date]</code>
			<code>[time]</code>
			<code>[gsm]</code>
		</p>
		<br />
		<hr />
		<br />
		<?php
		},
		IMN_SLUG
	);

	add_settings_field(
		'imn_booked_calendar_users_gsm_field',
		__( 'Choose users gsm number field for default calendar', 'iletimerkezi-notify' ),
		'imn_view_booked_users_gsm_field_callback',
		IMN_SLUG,
		'imn_booked_settings',
		[ 'id' => 'imn_booked_calendar_users_gsm_field', 'calendar_id' => 0 ]
	);

	$calendars = imn_model_booked_get_calendars();

	foreach ( $calendars as $calendar ) {

		$id = 'imn_booked_calendar_' . $calendar->term_id . '_users_gsm_field';

		add_settings_field(
			$id,
			sprintf( __( 'Choose users gsm number field for %s', 'iletimerkezi-notify' ), $calendar->name ),
			'imn_view_booked_users_gsm_field_callback',
			IMN_SLUG,
			'imn_booked_settings',
			[ 'id' => $id, 'calendar_id' => $calendar->term_id ]
		);

		register_setting( IMN_BOOKED_OPTIONS, $id );
	}

	add_settings_field(
		'imn_booked_new_appointment_created_template',
		__( 'Created template ', 'iletimerkezi-notify' ),
		'imn_view_booked_sms_template_callback',
		IMN_SLUG,
		'imn_booked_settings',
		[ 'id' => 'imn_booked_new_appointment_created_template' ]
	);

	add_settings_field(
		'imn_booked_appointment_approved_template',
		__( 'Approved template', 'iletimerkezi-notify' ),
		'imn_view_booked_sms_template_callback',
		IMN_SLUG,
		'imn_booked_settings',
		[ 'id' => 'imn_booked_appointment_approved_template' ]
	);

	add_settings_field(
		'imn_booked_appointment_cancelled_template',
		__( 'Cancelled template', 'iletimerkezi-notify' ),
		'imn_view_booked_sms_template_callback',
		IMN_SLUG,
		'imn_booked_settings',
		[ 'id' => 'imn_booked_appointment_cancelled_template' ]
	);

	add_settings_field(
		'imn_booked_appointment_reminder_buffer',
		__( 'Reminder Buffer', 'iletimerkezi-notify' ),
		'imn_view_booked_reminder_buffer_callback',
		IMN_SLUG,
		'imn_booked_settings',
		[ 'id' => 'imn_booked_appointment_reminder_buffer' ]
	);

	add_settings_field(
		'imn_booked_appointment_reminder_template',
		__( 'Reminder template', 'iletimerkezi-notify' ),
		'imn_view_booked_sms_template_callback',
		IMN_SLUG,
		'imn_booked_settings',
		[ 'id' => 'imn_booked_appointment_reminder_template' ]
	);

	register_setting( IMN_BOOKED_OPTIONS, 'imn_booked_calendar_users_gsm_field' );
	register_setting( IMN_BOOKED_OPTIONS, 'imn_booked_new_appointment_created_template' );
	register_setting( IMN_BOOKED_OPTIONS, 'imn_booked_appointment_approved_template' );
	register_setting( IMN_BOOKED_OPTIONS, 'imn_booked_appointment_cancelled_template' );
	register_setting( IMN_BOOKED_OPTIONS, 'imn_booked_appointment_reminder_buffer' );
	register_setting( IMN_BOOKED_OPTIONS, 'imn_booked_appointment_reminder_template' );
}


function imn_view_booked_users_gsm_field_callback( $args ) {

	$selected_field_val = get_option( $args['id'] );
	$booked_field_types_we_escape = [ 'required', 'checkboxes-label', 'single-checkbox', 'drop-down-label', 'single-drop-down' ];

	if ( $args['calendar_id'] > 0 ) {
		$custom_fields = json_decode(
			stripslashes( get_option( 'booked_custom_fields_' . $args['calendar_id'] ) ),
			true
		);
	} else {
		$custom_fields = json_decode(
			stripslashes( get_option( 'booked_custom_fields' ) ),
			true
		);
	}
	?>
	<select name="<?php echo $args['id']; ?>">
		<option value="0">Select a field</option>
		<?php
		foreach ( $custom_fields as $field ) {
			$parts = explode( '---', $field['name'] );
			if ( in_array( $parts[0], $booked_field_types_we_escape ) ) {
				continue;
			}
			?>
			<option <?php selected( $selected_field_val, $field['name'], true ); ?> value="<?php echo $field['name']; ?>">
				<?php echo $field['value']; ?></option>
			<?php
		}
		?>
	</select>
	<?php
}

function imn_view_booked_reminder_buffer_callback( $args ) {
	$buffer = get_option( $args['id'] );
	?>
	<select name="<?php echo $args['id']; ?>">
		<option <?php selected( 0, $buffer, true ); ?> value="0">At appointment time</option>
		<option <?php selected( 5, $buffer, true ); ?>value="5">5 minutes before</option>
		<option <?php selected( 10, $buffer, true ); ?> value="10">10 minutes before</option>
		<option <?php selected( 15, $buffer, true ); ?> value="15">15 minutes before</option>
		<option <?php selected( 30, $buffer, true ); ?> value="30" selected="">30 minutes before</option>
		<option <?php selected( 45, $buffer, true ); ?> value="45">45 minutes before</option>
		<option <?php selected( 60, $buffer, true ); ?> value="60">1 hour before</option>
		<option <?php selected( 120, $buffer, true ); ?> value="120">2 hours before</option>
		<option <?php selected( 180, $buffer, true ); ?> value="180">3 hours before</option>
		<option <?php selected( 240, $buffer, true ); ?> value="240">4 hours before</option>
		<option <?php selected( 300, $buffer, true ); ?> value="300">5 hours before</option>
		<option <?php selected( 360, $buffer, true ); ?> value="360">6 hours before</option>
		<option <?php selected( 720, $buffer, true ); ?> value="720">12 hours before</option>
		<option <?php selected( 1440, $buffer, true ); ?> value="1440">24 hours before</option>
		<option <?php selected( 2880, $buffer, true ); ?> value="2880">2 days before</option>
		<option <?php selected( 43200, $buffer, true ); ?> value="4320">3 days before</option>
		<option <?php selected( 5760, $buffer, true ); ?> value="5760">4 days before</option>
		<option <?php selected( 7200, $buffer, true ); ?> value="7200">5 days before</option>
		<option <?php selected( 8640, $buffer, true ); ?> value="8640">6 days before</option>
		<option <?php selected( 10080, $buffer, true ); ?> value="10080">1 week before</option>
		<option <?php selected( 20160, $buffer, true ); ?> value="20160">2 weeks before</option>
		<option <?php selected( 30240, $buffer, true ); ?> value="30240">3 weeks before</option>
		<option <?php selected( 40320, $buffer, true ); ?> value="40320">4 weeks before</option>
		<option <?php selected( 60480, $buffer, true ); ?> value="60480">6 weeks before</option>
		<option <?php selected( 80640, $buffer, true ); ?> value="80640">2 months before</option>
		<option <?php selected( 120960, $buffer, true ); ?> value="120960">3 months before</option>
	</select>
	<p>
		<?php
		_e( '<b>Please Note:</b> WordPress crons do not run unless someone visits your site. Because of this, some
		reminders might not get sent out. To prevent this from happening, you would need to setup cron to run from the
		server level using the following command:', 'iletimerkezi-notify' );
		?>
	</p>
	<br />
	<p>
		<code>*/5 * * * * wget -q -O - http://wp.m.com/wp-cron.php?doing_wp_cron</code>
	</p>
	<?php
}

function imn_view_booked_sms_template_callback( $args ) {
	?>
	<textarea class="regular-text" name="<?php echo $args['id']; ?>" rows="5"
		cols="50"><?php echo esc_textarea( get_option( $args['id'] ) ); ?></textarea>
	<?php
}