<?php

function imn_view_admin_menu() {

	$svg = file_get_contents( IMN_PLUGIN_DIR . 'assets/menu-icon.svg' );
	$icon = 'data:image/svg+xml;base64,' . base64_encode( $svg );

	add_menu_page(
		'İletimerkezi',
		'İletimerkezi',
		'manage_options',
		IMN_SLUG,
		'imn_view_admin_page',
		$icon
	);
}

function imn_view_admin_page() {

	$tab = isset( $_GET['tab'] ) ? $_GET['tab'] : 'settings';
	?>
	<div class="wrap">
		<h1>
			<?php echo __( 'İletimerkezi Settings', 'iletimerkezi-notify' ); ?>
		</h1>

		<h2 class="nav-tab-wrapper">
			<a href="?page=<?php echo IMN_SLUG; ?>&tab=settings"
				class="nav-tab <?php echo $tab === 'settings' ? 'nav-tab-active' : ''; ?>">
				<?php echo __( 'Settings', 'iletimerkezi-notify' ); ?>
			</a>
			<?php
			if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
				?>
				<a href="?page=<?php echo IMN_SLUG; ?>&tab=wc"
					class="nav-tab <?php echo $tab === 'wc' ? 'nav-tab-active' : ''; ?>">
					<?php echo __( 'Woocommerce', 'iletimerkezi-notify' ); ?>
				</a>
				<?php
			}

			if ( is_plugin_active( 'contact-form-7/wp-contact-form-7.php' ) ) {
				?>
				<a href="?page=<?php echo IMN_SLUG; ?>&tab=cf7"
					class="nav-tab <?php echo $tab === 'cf7' ? 'nav-tab-active' : ''; ?>">
					<?php echo __( 'Contact Form 7', 'iletimerkezi-notify' ); ?>
				</a>
				<?php
			}

			if ( is_plugin_active( 'booked/booked.php' ) ) {
				?>
				<a href="?page=<?php echo IMN_SLUG; ?>&tab=booked"
					class="nav-tab <?php echo $tab === 'booked' ? 'nav-tab-active' : ''; ?>">
					<?php echo __( 'Booked', 'iletimerkezi-notify' ); ?>
				</a>
				<?php
			}
			?>
			<a href="?page=<?php echo IMN_SLUG; ?>&tab=integration"
				class="nav-tab <?php echo $tab === 'integration' ? 'nav-tab-active' : ''; ?>">
				<?php echo __( 'Integrations', 'iletimerkezi-notify' ); ?>
			</a>
			<a href="?page=<?php echo IMN_SLUG; ?>&tab=reports"
				class="nav-tab <?php echo $tab === 'reports' ? 'nav-tab-active' : ''; ?>">
				<?php echo __( 'Reports', 'iletimerkezi-notify' ); ?>
			</a>
			<a href="?page=<?php echo IMN_SLUG; ?>&tab=logs"
				class="nav-tab <?php echo $tab === 'logs' ? 'nav-tab-active' : ''; ?>">
				<?php echo __( 'Logs', 'iletimerkezi-notify' ); ?>
			</a>
		</h2>

		<?php
		if ( $tab === 'settings' ) {
			imn_view_api_tab();
		}

		if ( $tab === 'wc' ) {
			imn_view_wc_tab();
		}

		if ( $tab === 'cf7' ) {
			imn_view_cf7_tab();
		}

		if ( $tab === 'booked' ) {
			imn_view_booked_tab();
		}

		if ( $tab === 'integration' ) {
			imn_view_integrations_tab();
		}

		if ( $tab === 'reports' ) {
			imn_view_reports_tab();
		}

		if ( $tab === 'logs' ) {
			imn_view_logs_tab();
		}
		?>
		<p class="alignright">
			<?php echo 'IMN-' . IMN_VERSION; ?>
		</p>
	</div>
	<?php
}

function imn_view_admin_fields_init() {

	imn_view_api_fields();
	
	if (is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
		imn_view_woocommerce_fields();
	}
	
	if (is_plugin_active( 'contact-form-7/wp-contact-form-7.php' ) ) {
		imn_view_cf7_fields();
	}
	 
	if (is_plugin_active( 'booked/booked.php' ) ) {
		imn_view_booked_fields();
	}

	/**
	 * @next other plugins settings initialization
	 */
}