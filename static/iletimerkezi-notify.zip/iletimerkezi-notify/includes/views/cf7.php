<?php

function imn_view_cf7_tab() {

	echo '<form method="post" action="options.php">';
	settings_fields( IMN_CF7_OPTIONS );
	do_settings_sections( IMN_CF7_OPTIONS );
	submit_button();
	echo '</form>';
}

function imn_view_cf7_fields() {

	add_settings_section(
		'imn_cf7_settings',
		__( 'Contact Form 7 Settings', 'iletimerkezi-notify' ),
		function () {
			?>
		<p class="description">
			<?php
				_e(
					'By adjusting the settings of the forms listed below, you can send sms to administrator numbers and users who fill out the form.',
					'iletimerkezi-notify'
				);
				?>
			<br />
			<?php
				_e( 'Only those who successfully fill out the form will receive an SMS.', 'iletimerkezi-notify' );
				?>
			<br />
			<?php
				_e( 'If you leave the message text field blank, the message will not be sent.', 'iletimerkezi-notify' );
				?>
		</p>
		<br />
		<hr />
		<br />
		<?php
		},
		IMN_CF7_OPTIONS
	);

	$forms = imn_model_cf7_get_form_data();

	foreach ( $forms as $form ) {

		$section_id = 'imn_cf7_' . $form['id'] . '_settings';
		$customer_gsm_id = 'imn_cf7_form_' . $form['id'] . '_customer_gsm';
		$customer_template_id = 'imn_cf7_form_' . $form['id'] . '_customer_template';
		$admin_template_id = 'imn_cf7_form_' . $form['id'] . '_admin_template';

		add_settings_section(
			$section_id,
			'',
			'imn_view_cf7_form_section_field_callback',
			IMN_CF7_OPTIONS,
			[ 'form' => $form ]
		);

		add_settings_field(
			$customer_gsm_id,
			__( 'User\'s gsm number', 'iletimerkezi-notify' ),
			'imn_view_cf7_gsm_field_callback',
			IMN_CF7_OPTIONS,
			$section_id,
			[ 'id' => $customer_gsm_id, 'form' => $form ]
		);

		add_settings_field(
			$customer_template_id,
			__( 'User template', 'iletimerkezi-notify' ),
			'imn_view_cf7_sms_template_callback',
			IMN_CF7_OPTIONS,
			$section_id,
			[ 'id' => $customer_template_id, 'form' => $form ]
		);

		add_settings_field(
			$admin_template_id,
			__( 'Admins template', 'iletimerkezi-notify' ),
			'imn_view_cf7_sms_template_callback',
			IMN_CF7_OPTIONS,
			$section_id,
			[ 'id' => $admin_template_id, 'form' => $form ]
		);

		register_setting( IMN_CF7_OPTIONS, $customer_gsm_id );
		register_setting( IMN_CF7_OPTIONS, $customer_template_id );
		register_setting( IMN_CF7_OPTIONS, $admin_template_id );
	}
}

function imn_view_cf7_form_section_field_callback( $args ) {
	?>
	<h3>
		<?php echo '"' . $args['form']['title'] . '"'; ?> -
		<?php _e( 'formu için SMS ayarları.' ); ?>
	</h3>
	<p class="description">
		Mesaj metni içerisinde kullanabileceğiniz değişkenler:
		<br />
		<br />
		<?php
		foreach ( $args['form']['tags'] as $tag ) {
			if ( empty( $tag['name'] ) ) {
				continue;
			}
			?>
			<code>[<?php echo $tag['name']; ?>]</code>
			<?php
		}
		?>
	</p>
	<?php
}

function imn_view_cf7_gsm_field_callback( $args ) {
	?>
	<select class="regular-text" name="<?php echo $args['id']; ?>">
		<?php foreach ( $args['form']['tags'] as $tag ) {
			?>
			<option value="<?php echo $tag['name']; ?>" <?php selected( $tag['name'], get_option( $args['id'] ), true ); ?>>
				<?php echo $tag['name']; ?>
			</option>
			<?php
		}
		?>
	</select>
	<?php
}

function imn_view_cf7_sms_template_callback( $args ) {
	?>
	<textarea class="regular-text" name="<?php echo $args['id']; ?>" rows="5"
		cols="50"><?php echo esc_textarea( get_option( $args['id'] ) ); ?></textarea>
	<?php
}