<?php

function imn_view_integrations_tab() {

	$result = '';
	if ( isset( $_GET['action'] ) && $_GET['action'] === 'save' ) {
		$result = imn_model_integration_insert();
	}

	if ( isset( $_GET['action'] ) && $_GET['action'] === 'delete' ) {
		imn_model_integration_delete( intval( $_GET['id'] ) );
	}

	if ( isset( $_GET['action'] ) && $_GET['action'] === 'toggle_status' ) {
		imn_model_integration_toggle_status(
			intval( $_GET['id'] ),
			intval( $_GET['current_status'] )
		);
	}

	if ( ! empty( $result ) ) {
		if ( $result ) {
			echo '<div class="notice notice-success is-dismissible"><p>' . __( 'Integration saved successfully.', 'iletimerkezi-notify' ) . '</p></div>';
		} else {
			echo '<div class="notice notice-error is-dismissible"><p>' . __( 'Integration could not be saved.', 'iletimerkezi-notify' ) . '</p></div>';
		}
	}
	?>
	<h2>
		<?php echo __( 'Advanced Integrations', 'iletimerkezi-notify' ); ?>
	</h2>
	<p class="description">
		<?php
		$plugin_editor = get_site_url() . '/wp-admin/plugin-editor.php?file=iletimerkezi_notify%2Fincludes%2Fuser-functions.php&plugin=iletimerkezi_notify%2Filetimerkezi_notify.php';
		echo sprintf( __(
			'In order to add an SMS sending feature to a plugin that is not currently integrated, 
			you can match the functions you add from <a target="__blank" href="%s">this address</a> to whichever hook you want to work here.
			<br />  
			If you do not have code knowledge, you should be very careful when setting up in this section, 
			you can ensure that your plugin does not work completely. 
			<br />
			If this happens, you can connect to your server via FTP and change <b>iletimerkezi_notify/includes/user-functions.php</b> file, 
			<br />
			Change "define( \'IMN_CUSTOM_INTEGRATION\', <b>true</b> );" to "define( \'IMN_CUSTOM_INTEGRATION\', <b>false</b> );".',
			'iletimerkezi-notify'
		), $plugin_editor );
		?>
	</p>
	<br />
	<hr />
	<br />
	<form method="post" action="?page=im-settings&tab=integration&action=save">
		<table class="form-table">
			<tr valign="top">
				<th scope="row">
					<?php echo __( 'Hook Type', 'iletimerkezi-notify' ); ?>
				</th>
				<td>
					<select class="regular-text" name="hook_type" required>
						<option value="action">
							<?php echo __( 'Action', 'iletimerkezi-notify' ); ?>
						</option>
						<option value="filter">
							<?php echo __( 'Filter', 'iletimerkezi-notify' ); ?>
						</option>
					</select>
				</td>
			</tr>
			<tr valign="top">
				<th scope="row">
					<?php echo __( 'Hook Name', 'iletimerkezi-notify' ); ?>
				</th>
				<td><input class="regular-text" type="text" name="hook_name" value="" required /></td>
			</tr>
			<tr valign="top">
				<th scope="row">
					<?php echo __( 'Function Name', 'iletimerkezi-notify' ); ?>
				</th>
				<td><input class="regular-text" type="text" name="function_name" value="" required /></td>
			</tr>
			<tr valign="top">
				<th scope="row">
					<?php echo __( 'Priority', 'iletimerkezi-notify' ); ?>
				</th>
				<td><input class="regular-text" type="text" name="priority" value="" required /></td>
			</tr>
			<tr valign="top">
				<th scope="row">
					<?php echo __( 'Accepted Args', 'iletimerkezi-notify' ); ?>
				</th>
				<td><input class="regular-text" type="text" name="accepted_args" value="" required /></td>
			</tr>
			<tr valign="top">
				<th scope="row">
					<?php echo __( 'Status', 'iletimerkezi-notify' ); ?>
				</th>
				<td>
					<input type="checkbox" name="status" value="1" checked />
					<?php echo __( 'Enabled', 'iletimerkezi-notify' ); ?>
				</td>
			</tr>
		</table>
		<input type="submit" name="submit" class="button-primary"
			value="<?php echo __( 'Save', 'iletimerkezi-notify' ); ?>" />
	</form>
	<br />
	<br />
	<h2>
		<?php _e( 'Custom Integration List', 'iletimerkezi-notify' ); ?>
	</h2>
	<p class="description">
		<?php
		_e(
			'You can manage the custom integrations you have defined from this section.',
			'iletimerkezi-notify'
		);
		?>
	</p>
	<br />
	<hr />
	<?php
	$integrations = new IMN_Table_Integrations();
	$integrations->prepare_items();
	$integrations->display();
}