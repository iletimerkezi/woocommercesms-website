<?php

function imn_view_reports_tab() {

	$reports = new IMN_Table_Report();
	$reports->prepare_items();
	?>
	<div>
		<h2>
			<?php echo __( 'Reports', 'iletimerkezi-notify' ); ?>
		</h2>
		<p></p>
		<form method="get">
			<input type="hidden" name="page" value="<?php echo esc_attr( $_REQUEST['page'] ); ?>">
			<input type="hidden" name="tab" value="reports">
			<?php $reports->search_box( __( 'Search GSM', 'my-textdomain' ), 'search-gsm' ); ?>
			<?php $reports->display(); ?>
		</form>
	</div>
	<?php
}