<?php

function imn_view_general_tab() {

	echo '<form method="post" action="options.php">';
	settings_fields( IMN_OPTIONS );
	do_settings_sections( IMN_SLUG );
	submit_button();
	echo '</form>';
}

function imn_view_api_fields() {

	add_settings_section(
		'imn_api_settings',
		__( 'API Settings', 'iletimerkezi-notify' ),
		function () {
			?>
		<p class="description">
			<?php
				_e(
					'If you leave the message text section blank, the message will not be sent. This section is the section where you make the necessary settings for the integration of your wordpress site with the communication center. With this plugin, you add the ability to send sms to the plugins you use on your site. You can already start using woocommerce, contact form 7 plugins by making the settings on this page. For other plugins, you can perform integration by looking at the integration tab.',
					'iletimerkezi-notify'
				);
				?>
			<?php
				_e(
					'For more detailed information, you can review <a target="_blank" href="https://www.woocommercesms.com">documentation</a> or <b>destek@emarka.com.tr</b> - <b You can contact us via >02125434210</b>.',
					'iletimerkezi-notify'
				);
				?>
		</p>
		<br />
		<hr />
		<br />
		<?php
		},
		IMN_SLUG
	);

	$fields = [ 
		[ 
			'id' => 'imn_api_key',
			'callback' => 'input',
			'title' => __( 'API Key', 'iletimerkezi-notify' ),
			'description' => __( 'You can get it from https://www.iletimerkezi.com/panel/settings/api/keys', 'iletimerkezi-notify' )
		],
		[ 
			'id' => 'imn_api_hash',
			'callback' => 'input',
			'title' => __( 'API Hash', 'iletimerkezi-notify' ),
			'description' => __( 'You can get it from https://www.iletimerkezi.com/panel/settings/api/keys', 'iletimerkezi-notify' )
		],
		[ 
			'id' => 'imn_api_sender',
			'callback' => 'input',
			'title' => __( 'Sender', 'iletimerkezi-notify' ),
			'description' => __( 'Your approved sender in your iletimerkezi account, sender is case sensitive', 'iletimerkezi-notify' )
		],
		[ 
			'id' => 'imn_admin_phone',
			'callback' => 'input',
			'title' => __( 'Admin Phones', 'iletimerkezi-notify' ),
			'description' => __( 'Enter your phone numbers separated by commas. Example: 532123xxxx,532123xxxx', 'iletimerkezi-notify' )
		],
		[ 
			'id' => 'imn_webhook',
			'callback' => 'webhook',
			'title' => __( 'Webhook', 'iletimerkezi-notify' ),
			'description' => __( 'Register the webhook address at https://www.iletimerkezi.com/panel/settings/api/webhooks so that you can follow the SMS reports on wordpress.', 'iletimerkezi-notify' )
		],
		[ 
			'id' => 'imn_default_country_code',
			'callback' => 'country_picker',
			'title' => __( 'Default Country', 'iletimerkezi-notify' ),
			'description' => __( 'Numbers without a country code get this country code by default.', 'iletimerkezi-notify' )
		],
		[ 
			'id' => 'imn_debug',
			'callback' => 'checkbox',
			'title' => __( 'Debug', 'iletimerkezi-notify' ),
			'description' => __( 'It is used to detect errors that occur in the plugin, turn it off while actively using the plugin, it will slow down your system', 'iletimerkezi-notify' )
		],
		[ 
			'id' => 'imn_iys',
			'callback' => 'checkbox',
			'title' => __( 'Use IYS', 'iletimerkezi-notify' ),
			'description' => __( 'It allows the sent messages to be queried over IYS.', 'iletimerkezi-notify' )
		],
		[ 
			'id' => 'imn_iys_list',
			'callback' => 'selectbox',
			'options' => [ 'BIREYSEL', 'TACIR' ],
			'title' => __( 'IYS List', 'iletimerkezi-notify' ),
			'description' => __( 'Specifies from which list on the IYS the permission of the numbers will be queried.', 'iletimerkezi-notify' )
		]
	];

	foreach ( $fields as $field ) {
		add_settings_field(
			$field['id'],
			$field['title'],
			function () use ($field) {
				if ( $field['callback'] === 'input' ) {
					imn_view_general_input_callback( $field );
				}

				if ( $field['callback'] === 'checkbox' ) {
					imn_view_general_checkbox_callback( $field );
				}

				if ( $field['callback'] === 'selectbox' ) {
					imn_view_general_selectbox_callback( $field );
				}

				if ( $field['callback'] === 'country_picker' ) {
					echo imn_view_select_country( $field );
				}

				if ( $field['callback'] === 'webhook' ) {
					imn_view_general_webhook_callback( $field );
				}
			},
			IMN_SLUG,
			'imn_api_settings'
		);

		register_setting( IMN_OPTIONS, $field['id'] );
	}
}

function imn_view_general_webhook_callback( $field ) {

	$webhook = get_site_url() . '/wp-admin/admin-ajax.php?action=imn_webhook';
	?>
	<input class="large-text" onfocus="this.select();" type="text" name="<?php echo $field['id']; ?>"
		value="<?php echo $webhook; ?>" readonly>
	<p class="description">
		<?php echo $field['description']; ?>
	</p>
	<?php
}

function imn_view_general_input_callback( $field ) {
	?>
	<input class="regular-text" type="text" name="<?php echo $field['id']; ?>"
		value="<?php echo get_option( $field['id'] ); ?>">
	<p class="description">
		<?php echo $field['description']; ?>
	</p>
	<?php
}

function imn_view_general_checkbox_callback( $field ) {
	?>
	<input type="checkbox" name="<?php echo $field['id']; ?>" value="1" <?php checked( 1, get_option( $field['id'] ), true ); ?>>
	<p class="description">
		<?php echo $field['description']; ?>
	</p>
	<?php
}

function imn_view_general_selectbox_callback( $field ) {
	?>
	<select class="regular-text" name="<?php echo $field['id']; ?>">
		<?php
		foreach ( $field['options'] as $option ) {
			?>
			<option value="<?php echo $option; ?>" <?php selected( $option, get_option( $field['id'] ), true ); ?>><?php echo $option; ?></option>
			<?php
		}
		?>
	</select>
	<p class="description">
		<?php echo $field['description']; ?>
	</p>
	<?php
}