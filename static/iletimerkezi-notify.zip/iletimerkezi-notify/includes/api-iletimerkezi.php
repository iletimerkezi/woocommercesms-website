<?php

function imn_api_send_sms( $phone, $message, $plugin = '' ) {

	imn_log( __FUNCTION__,
		[ 
			'args' => [ 
				'phone' => $phone,
				'message' => $message,
				'plugin' => $plugin
			]
		]
	);

	$key = get_option( 'imn_api_key' );
	$hash = get_option( 'imn_api_hash' );
	$sender = get_option( 'imn_api_sender' );
	$iys = get_option( 'imn_iys' );
	$iys_list = get_option( 'imn_iys_list' );
	$country = get_option( 'imn_default_country_code' );

	if ( empty( $key ) || empty( $hash ) || empty( $sender ) || empty( $phone ) || empty( $message ) ) {
		imn_model_report_insert(
			null,
			$phone,
			$message,
			'error',
			'API key, hash or sender is empty'
		);
		return;
	}

	$url = 'https://api.iletimerkezi.com/v1/send-sms/json';

	$data = [ 
		'request' => [ 
			'authentication' => [ 
				'key' => $key,
				'hash' => $hash
			],
			'order' => [ 
				'sender' => $sender,
				'sendDateTime' => [],
				'iys' => $iys,
				'iysList' => $iys_list,
				'message' => [ 
					'text' => $message,
					'receipents' => [ 
						'number' => [ $phone ]
					]
				]
			]
		]
	];

	imn_log(
		__FUNCTION__,
		[ 
			'message' => 'Send payload',
			'args' => [ 
				'data' => $data
			]
		]
	);

	$json_data = wp_json_encode( $data );

	$args = [ 
		'headers' => [ 
			'Content-Type' => 'application/json'
		],
		'body' => $json_data,
		'timeout' => 60,
		'sslverify' => false
	];

	$response = wp_remote_post( $url, $args );

	if ( is_wp_error( $response ) ) {

		imn_model_report_insert(
			null,
			$phone,
			$message,
			'error',
			$response->get_error_message()
		);
		return;
	}

	$result = json_decode( wp_remote_retrieve_body( $response ) );

	if ( $result === null || $result === false ) {
		imn_model_report_insert(
			null,
			$phone,
			$message,
			'error',
			'Invalid JSON'
		);
		return;
	}

	if ( $result->response->status->code !== 200 ) {
		imn_model_report_insert(
			null,
			$phone,
			$message,
			'error',
			$result->response->status->message
		);
		return;
	}

	imn_model_report_insert(
		$result->response->order->id,
		$phone,
		$message,
		'waiting',
		''
	);
}

function imn_api_handle_webhook() {
	global $wpdb;

	$payload = file_get_contents( 'php://input' );
	$data = json_decode( $payload );

	imn_log( __FUNCTION__, [ 'args' => [ 'data' => $data, 'raw' => $payload ] ] );

	if ( $data->report->status === 'accepted' ) {
		return wp_send_json_success( null, 200 );
	}

	$status = $data->report->status === 'delivered' ? 'DELIVERED' : 'UNDELIVERED';

	imn_model_report_update( $status, $data->report->packet_id );

	return wp_send_json_success( null, 200 );
}