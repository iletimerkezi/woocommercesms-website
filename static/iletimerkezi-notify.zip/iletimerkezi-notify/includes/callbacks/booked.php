<?php
function imn_callback_booked_new_appointment_created( $post_id ) {

	imn_log( __FUNCTION__, [ 'args' => $post_id, 'post' => $_POST ] );

	$tokens = booked_get_appointment_tokens( $post_id );

	if ( ! isset( $_POST['calendar_id'] ) ) {
		imn_log( __FUNCTION__, [ 'msg' => 'calendar_id not found!' ] );
		return false;
	}

	if ( $_POST['calendar_id'] > 0 ) {
		$gsm_field_id = get_option( 'imn_booked_calendar_' . $_POST['calendar_id'] . '_users_gsm_field' );
	} else {
		$gsm_field_id = get_option( 'imn_booked_calendar_users_gsm_field' );
	}

	imn_log( __FUNCTION__, [ 'tokens' => $tokens, 'gsm_field_id' => $gsm_field_id ] );

	$template = get_option( 'imn_booked_new_appointment_created_template' );

	imn_model_shared_insert(
		$post_id,
		'booked',
		json_encode( [ 'gsm' => $_POST[ $gsm_field_id ], 'calendar_id' => $_POST['calendar_id'] ] )
	);

	imn_api_send_sms(
		$_POST[ $gsm_field_id ],
		imn_callback_shared_merge_sms_args(
			$template, array_merge( $tokens, [ 'gsm' => $_POST[ $gsm_field_id ] ] )
		),
		'booked'
	);
}

function imn_callback_booked_appointment_approved( $appointment_id ) {
	imn_log( __FUNCTION__, [ 'args' => $appointment_id, 'post' => $_POST ] );

	$tokens = booked_get_appointment_tokens( $appointment_id );
	$shared = json_decode( imn_model_shared_get( $appointment_id, 'booked' ), true );

	imn_log( __FUNCTION__, [ 'shared' => $shared, 'tokens' => $tokens ] );

	if ( ! isset( $shared['calendar_id'] ) ) {
		imn_log( __FUNCTION__, [ 'msg' => 'calendar_id not found!' ] );
		return false;
	}

	$template = get_option( 'imn_booked_appointment_approved_template' );

	imn_api_send_sms(
		$shared['gsm'],
		imn_callback_shared_merge_sms_args(
			$template, array_merge( $tokens, [ 'gsm' => $shared['gsm'] ] )
		),
		'booked'
	);
}

function imn_callback_booked_appointment_cancelled( $appointment_id ) {

	imn_log( __FUNCTION__, [ 'args' => $appointment_id, 'post' => $_POST ] );

	$tokens = booked_get_appointment_tokens( $appointment_id );
	$shared = json_decode( imn_model_shared_get( $appointment_id, 'booked' ), true );

	imn_log( __FUNCTION__, [ 'shared' => $shared, 'tokens' => $tokens ] );

	if ( ! isset( $shared['calendar_id'] ) ) {
		imn_log( __FUNCTION__, [ 'msg' => 'calendar_id not found!' ] );
		return false;
	}

	$template = get_option( 'imn_booked_appointment_cancelled_template' );

	imn_api_send_sms(
		$shared['gsm'],
		imn_callback_shared_merge_sms_args(
			$template, array_merge( $tokens, [ 'gsm' => $shared['gsm'] ] )
		),
		'booked'
	);
}

function imn_callback_booked_appointment_reminder() {

	imn_log( __FUNCTION__, [ 'msg' => 'init' ] );

	$buffer = get_option( 'imn_booked_appointment_reminder_buffer', 30 );
	$start = current_time( 'timestamp' );
	$end = strtotime( date_i18n( 'Y-m-d H:i:s', current_time( 'timestamp' ) ) . ' + ' . $buffer . ' minutes' );

	imn_log( __FUNCTION__, [ 'buffer' => $buffer, 'start' => $start, 'end' => $end ] );

	$args = [ 
		'post_type' => 'booked_appointments',
		'posts_per_page' => 500,
		'post_status' => [ 'publish', 'future' ],
		'meta_query' => [ 
			[ 
				'key' => '_appointment_timestamp',
				'value' => [ $start, $end ],
				'compare' => 'BETWEEN',
			]
		]
	];

	$appointments = new WP_Query( $args );

	if ( $appointments->have_posts() ) {
		foreach ( $appointments->posts as $post ) {

			$already_sent = get_post_meta( $post->ID, '_appointment_user_reminder_sms_sent', true );

			if ( $already_sent ) {
				imn_log( __FUNCTION__, [ 'message' => 'Already send' ] );
				continue;
			}

			$tokens = booked_get_appointment_tokens( $post->ID );
			$shared = json_decode( imn_model_shared_get( $post->ID, 'booked' ), true );
			$template = get_option( 'imn_booked_appointment_reminder_template' );

			imn_api_send_sms(
				$shared['gsm'],
				imn_callback_shared_merge_sms_args(
					$template, array_merge( $tokens, [ 'gsm' => $shared['gsm'] ] )
				),
				'booked'
			);

			update_post_meta( $post->ID, '_appointment_user_reminder_sms_sent', true );
		}
	}
}

function imn_callback_booked_reminder_cron_activate() {

	imn_log( __FUNCTION__, [ 'msg' => 'imn_callback_booked_reminder_cron_activate' ] );

	if ( ! wp_next_scheduled( 'imn_booked_appointment_reminder_cron' ) ) {
		wp_schedule_event(
			time(),
			'imn_cron_everyfive',
			'imn_booked_appointment_reminder_cron'
		);
	}
}

function imn_callback_booked_reminder_cron_deactivate() {
	$timestamp = wp_next_scheduled( 'imn_booked_appointment_reminder_cron' );
	wp_unschedule_event( $timestamp, 'imn_booked_appointment_reminder_cron' );
}