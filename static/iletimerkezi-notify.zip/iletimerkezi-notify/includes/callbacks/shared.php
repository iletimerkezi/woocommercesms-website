<?php

function imn_flatten_array( $data, $prefix = '' ) {
	$result = [];

	foreach ( $data as $key => $value ) {
		if ( is_array( $value ) ) {
			$new_prefix = $prefix . $key . '.';
			$result = array_merge( $result, imn_flatten_array( $value, $new_prefix ) );
		} else {
			$result[ $prefix . $key ] = $value;
		}
	}

	return $result;
}

function imn_callback_shared_merge_sms_args( $template, $args ) {

	$args = imn_flatten_array( $args );

	imn_log( __FUNCTION__, [ 'template' => $template, 'args' => $args ] );

	foreach ( $args as $key => $value ) {
		$template = str_replace( "[" . $key . "]", $value, $template );
	}

	imn_log( __FUNCTION__, [ 'template' => $template ] );

	return $template;
}