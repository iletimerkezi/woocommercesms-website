<?php

function imn_callback_cf7_sms_sent( $contact_form ) {

	imn_log( __FUNCTION__, [ 'message' => 'imn_callback_cf7_sms_sent init' ] );

	$submission = WPCF7_Submission::get_instance();

	if ( $submission ) {

		imn_log( __FUNCTION__, [ 'message' => 'imn_callback_cf7_sms_sent submission' ] );

		$form_id = $contact_form->id();
		$posted_data = $submission->get_posted_data();
		$gsm_field = get_option( 'imn_cf7_form_' . $form_id . '_customer_gsm' );
		$customer_template = get_option( 'imn_cf7_form_' . $form_id . '_customer_template' );
		$admin_template = get_option( 'imn_cf7_form_' . $form_id . '_admin_template' );

		if ( ! empty( $gsm_field ) && ! empty( $customer_template ) ) {
			$filtered = apply_filters( 'imn_callback_cf7_sms_sent_customer', [ 'posted_data' => $posted_data ] );
			$posted_data = array_merge(
				$posted_data,
				is_array( $filtered ) ? $filtered : []
			);
			imn_log( __FUNCTION__, [ 'args' => $posted_data ] );
			imn_api_send_sms(
				$posted_data[ $gsm_field ],
				imn_callback_shared_merge_sms_args( $customer_template, $posted_data ),
				'cf7'
			);
		}

		if ( ! empty( $admin_template ) ) {
			$filtered = apply_filters( 'imn_callback_cf7_sms_sent_admin', [ 'posted_data' => $posted_data ] );
			$posted_data = array_merge(
				$posted_data,
				is_array( $filtered ) ? $filtered : []
			);
			imn_log( __FUNCTION__, [ 'args' => $posted_data ] );
			$admins = get_option( 'imn_admin_phone' );
			foreach ( explode( ',', $admins ) as $admin ) {
				imn_api_send_sms(
					$admin,
					imn_callback_shared_merge_sms_args( $admin_template, $posted_data ),
					'cf7'
				);
			}
		}

	}
}