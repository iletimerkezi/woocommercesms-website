<?php

function imn_callback_wc_create_sms_args( $order_id ) {

	imn_log( __FUNCTION__, [ 'order_id' => $order_id ] );

	$order = wc_get_order( $order_id );

	$args = [ 
		'order_id' => $order_id,
		'first_name' => $order->get_billing_first_name(),
		'last_name' => $order->get_billing_last_name(),
		'email' => $order->get_billing_email(),
		'phone' => $order->get_billing_phone(),
		'total' => $order->get_total(),
	];

	$metas = $order->get_meta_data();
	foreach ( $metas as $meta ) {
		$meta_data = $meta->get_data();
		$args[ $meta_data['key'] ] = $meta_data['value'];
	}

	imn_log( __FUNCTION__, [ 'args' => $args, 'message' => 'before apply filter' ] );

	$filtered = apply_filters( 'imn_callback_wc_create_sms_args', $order_id );

	$args = array_merge(
		$args,
		is_array( $filtered ) ? $filtered : []
	);

	imn_log( __FUNCTION__, [ 'args' => $args, 'message' => 'after apply filter' ] );

	return $args;
}

function imn_callback_wc_order_status_changed( $order_id, $old_status, $new_status ) {

	imn_log(
		__FUNCTION__,
		[ 
			'args' => [ 
				'order_id' => $order_id,
				'old_status' => $old_status,
				'new_status' => $new_status
			]
		]
	);

	$args = imn_callback_wc_create_sms_args( $order_id );
	$template = get_option( 'imn_wc_' . $new_status );
	$enable = get_option( 'imn_wc_' . $new_status . '_enabled' );

	if ( $old_status === $new_status ) {
		imn_log( __FUNCTION__, [ 'message' => [ 'old_status === new_status' ] ] );
		return;
	}

	if ( ! $enable ) {
		imn_log( __FUNCTION__, [ 'message' => 'not enable' ] );
		return;
	}

	if ( empty( $template ) ) {
		imn_log( __FUNCTION__, [ 'message' => 'template empty' ] );
		return;
	}

	if ( empty( $args['phone'] ) ) {
		imn_log( __FUNCTION__, [ 'message' => 'phone empty' ] );
		return;
	}

	$args += array_merge(
		$args,
		apply_filters( 'imn_callback_wc_order_status_changed', [ 'order_id' => $order_id, 'old_status' => $old_status, 'new_status' => $new_status ] )
	);

	imn_log( __FUNCTION__, [ 'args' => $args, 'message' => 'After apply filter' ] );

	imn_api_send_sms(
		$args['phone'],
		imn_callback_shared_merge_sms_args( $template, $args ),
		'woocommerce'
	);
}

function imn_callback_wc_new_order_created( $order_id, $posted_data, $order ) {

	imn_log( __FUNCTION__, [ 'args' => [ 'order_id' => $order_id ] ] );

	$args = imn_callback_wc_create_sms_args( $order_id );
	$template = get_option( 'imn_wc_new_order_for_admin' );
	$enable = get_option( 'imn_wc_new_order_for_admin_enabled' );
	$admins = get_option( 'imn_admin_phone' );

	if ( ! $enable ) {
		imn_log( __FUNCTION__, [ 'message' => 'not enable' ] );
		return;
	}

	if ( empty( $template ) ) {
		imn_log( __FUNCTION__, [ 'message' => 'template empty' ] );
		return;
	}

	if ( empty( $admins ) ) {
		imn_log( __FUNCTION__, [ 'message' => 'admins empty ' . $admins ] );
		return;
	}

	imn_log( __FUNCTION__, [ 'args' => $args ] );

	$args = array_merge(
		$args,
		apply_filters( 'imn_callback_wc_new_order_created', [ 'order_id' => $order_id ] )
	);

	imn_log( __FUNCTION__, [ 'args' => $args ] );

	$admins = explode( ',', $admins );

	foreach ( $admins as $admin ) {
		imn_api_send_sms(
			$admin,
			imn_callback_shared_merge_sms_args( $template, $args ),
			'woocommerce'
		);
	}
}

function imn_callback_wc_new_customer_order_note( $properties ) {

	imn_log( __FUNCTION__, [ 'init_args' => $properties ] );

	$args = imn_callback_wc_create_sms_args( $properties['order_id'] );
	$enable = get_option( 'imn_wc_new_customer_order_note_enabled' );

	if ( ! $enable ) {
		imn_log( __FUNCTION__, [ 'message' => 'not enable' ] );
		return;
	}

	if ( empty( $properties['customer_note'] ) ) {
		imn_log( __FUNCTION__, [ 'message' => 'customer note empty' ] );
		return;
	}

	if ( empty( $args['phone'] ) ) {
		imn_log( __FUNCTION__, [ 'message' => 'phone empty' ] );
		return;
	}

	$filtered = apply_filters( 'imn_callback_wc_new_customer_order_note', [ 'order_id' => $properties['order_id'] ] );

	$args = array_merge(
		$args,
		is_array( $filtered ) ? $filtered : []
	);

	imn_log( __FUNCTION__, [ 'final_args' => $args ] );

	imn_api_send_sms(
		$args['phone'],
		imn_callback_shared_merge_sms_args( $properties['customer_note'], $args ),
		'woocommerce'
	);
}