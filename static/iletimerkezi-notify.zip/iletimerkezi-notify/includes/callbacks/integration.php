<?php

function imn_callback_integration_register() {

	$integrations = imn_model_integration_all();

	if ( ! IMN_CUSTOM_INTEGRATION ) {
		imn_log( __FUNCTION__, [ 'message' => 'user-functions.php: IMN_CUSTOM_INTEGRATION is not defined or set to false.' ] );
		return;
	}

	if ( ! is_null( $integrations ) ) {
		foreach ( $integrations as $integration ) {

			if ( ! $integration['status'] ) {
				continue;
			}

			if ( empty( $integration['hook'] ) || empty( $integration['function'] ) ) {
				continue;
			}

			if ( $integration['hook_type'] === 'action' ) {
				add_action(
					$integration['hook'],
					$integration['function'],
					$integration['priority'],
					$integration['accepted_args']
				);
			}

			if ( $integration['hook_type'] === 'filter' ) {
				add_filter(
					$integration['hook'],
					$integration['function'],
					$integration['priority'],
					$integration['accepted_args']
				);
			}
		}
	}
}