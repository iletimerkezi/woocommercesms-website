<?php

function imn_log( $level = 'INFO', $message ) {
	global $wpdb;

	if ( ! get_option( 'imn_debug' ) ) {
		return;
	}

	$wpdb->insert( $wpdb->prefix . 'imn_logs', [ 
		'level' => $level,
		'message' => json_encode( $message ),
		'created_at' => current_time( 'mysql' )
	] );
}