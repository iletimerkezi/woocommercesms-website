<?php

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class IMN_Table_Integrations extends WP_List_Table {
	public function __construct() {
		parent::__construct( [ 
			'singular' => __( 'Integration', 'iletimerkezi-notify' ),
			'plural' => __( 'Integrations', 'iletimerkezi-notify' ),
			'ajax' => false,
		] );
	}

	public function column_default( $item, $column_name ) {
		if ( $column_name === 'status' ) {
			return $item[ $column_name ] ? __( 'Enabled', 'iletimerkezi-notify' ) : __( 'Disabled', 'iletimerkezi-notify' );
		}

		return $item[ $column_name ];
	}

	public function get_columns() {
		return [ 
			'hook_type' => __( 'Hook Type', 'iletimerkezi-notify' ),
			'hook' => __( 'Hook', 'iletimerkezi-notify' ),
			'function_name' => __( 'Function Name', 'iletimerkezi-notify' ),
			'status' => __( 'Status', 'iletimerkezi-notify' ),
			'priority' => __( 'Priority', 'iletimerkezi-notify' ),
			'accepted_args' => __( 'Accepted Args', 'iletimerkezi-notify' ),
			'created_at' => __( 'Created At', 'iletimerkezi-notify' ),
			'actions' => __( 'Actions', 'iletimerkezi-notify' )
		];
	}

	public function prepare_items() {
		global $wpdb;
		$table_name = $wpdb->prefix . 'imn_integrations';

		$this->items = $wpdb->get_results( "SELECT * FROM $table_name", ARRAY_A );
		$this->_column_headers = [ $this->get_columns() ];
	}

	public function column_actions( $item ) {
		$delete_url = add_query_arg( [ 
			'action' => 'delete',
			'id' => $item['id'],
		] );

		$toggle_status_url = add_query_arg( [ 
			'action' => 'toggle_status',
			'id' => $item['id'],
			'current_status' => $item['status'],
		] );

		return sprintf(
			'<a href="%1$s" onclick="return confirm(\'%3$s\');">%2$s</a> | <a href="%4$s">%5$s</a>',
			$delete_url,
			__( 'Delete', 'iletimerkezi-notify' ),
			__( "Are you sure you want to delete this integration?", "imn" ),
			$toggle_status_url,
			$item['status'] ? __( 'Disable', 'iletimerkezi-notify' ) : __( 'Enable', 'iletimerkezi-notify' )
		);
	}
}

function imn_model_integration_all() {
	global $wpdb;

	$table_name = $wpdb->prefix . 'imn_integrations';
	$results = $wpdb->get_results( "SELECT * FROM {$table_name}", ARRAY_A );

	return $results;
}

function imn_model_integration_insert() {
	global $wpdb;

	$type = isset( $_POST['hook_type'] ) ? $_POST['hook_type'] : 'action';
	$hook = sanitize_text_field( $_POST['hook_name'] );
	$function = sanitize_text_field( $_POST['function_name'] );
	$status = isset( $_POST['status'] ) ? 1 : 0;
	$priority = isset( $_POST['priority'] ) ? intval( $_POST['priority'] ) : 10;
	$accepted_args = isset( $_POST['accepted_args'] ) ? intval( $_POST['accepted_args'] ) : 1;

	return $wpdb->insert(
		$wpdb->prefix . 'imn_integrations',
		[ 
			'hook_type' => $type,
			'hook' => $hook,
			'function_name' => $function,
			'status' => $status,
			'priority' => $priority,
			'accepted_args' => $accepted_args,
			'created_at' => current_time( 'mysql', 1 )
		],
		[ '%s', '%s', '%s', '%d', '%d', '%d', '%s' ]
	);
}

function imn_model_integration_delete( $id ) {
	global $wpdb;

	$wpdb->delete( $wpdb->prefix . 'imn_integrations', [ 'id' => $id ], [ '%d' ] );
}

function imn_model_integration_toggle_status( $id, $current ) {
	global $wpdb;

	$wpdb->update(
		$wpdb->prefix . 'imn_integrations',
		[ 'status' => $current == 1 ? 0 : 1 ],
		[ 'id' => $id ],
		[ '%d' ],
		[ '%d' ]
	);
}