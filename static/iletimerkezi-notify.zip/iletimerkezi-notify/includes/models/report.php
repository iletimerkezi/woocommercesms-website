<?php

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class IMN_Table_Report extends WP_List_Table {

	public function __construct() {
		parent::__construct( [ 
			'singular' => __( 'Report', 'my-textdomain' ),
			'plural' => __( 'Reports', 'my-textdomain' ),
			'ajax' => false,
		] );
	}

	function get_columns() {
		return [ 
			'id' => __( 'ID', 'my-textdomain' ),
			'gsm' => __( 'GSM', 'my-textdomain' ),
			'message' => __( 'Message', 'my-textdomain' ),
			'status' => __( 'Status', 'my-textdomain' ),
			'error_msg' => __( 'Error', 'my-textdomain' ),
			'created_at' => __( 'Created At', 'my-textdomain' ),
			'updated_at' => __( 'Updated At', 'my-textdomain' ),
		];
	}

	function column_default( $item, $column_name ) {
		return isset( $item->$column_name ) ? $item->$column_name : '';
	}

	function prepare_items() {
		global $wpdb;
		$columns = $this->get_columns();
		$hidden = [];
		$sortable = $this->get_sortable_columns();
		$this->_column_headers = [ $columns, $hidden, $sortable ];

		$per_page = 50;
		$current_page = $this->get_pagenum();
		$table_name = $wpdb->prefix . 'imn_reports';

		// GSM alanına göre arama işlemi
		$search = '';
		if ( ! empty( $_REQUEST['s'] ) ) {
			$search = $wpdb->prepare( " WHERE gsm LIKE '%%%s%%'", $_REQUEST['s'] );
		}

		$total_items = $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}{$search}" );
		$this->set_pagination_args( [ 
			'total_items' => $total_items,
			'per_page' => $per_page
		] );

		$offset = ( $current_page - 1 ) * $per_page;
		$this->items = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table_name}{$search} ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, $offset ) );
	}

	function extra_tablenav( $which ) {
		if ( $which == 'top' ) {
			?>
			<div class="alignleft actions">
				<input type="search" id="search-input" name="s"
					value="<?php echo isset( $_REQUEST['s'] ) ? esc_attr( $_REQUEST['s'] ) : ''; ?>">

				<input type="submit" id="search-submit" class="button" value="<?php echo __( 'Search GSM', 'my-textdomain' ); ?>">
			</div>
			<?php
		}
	}
}

function imn_model_report_update( $status, $packet_id ) {
	global $wpdb;

	$wpdb->update(
		$wpdb->prefix . 'imn_reports',
		[ 'status' => $status ],
		[ 'im_id' => $packet_id ],
		[ '%d' ],
		[ '%d' ]
	);
}

function imn_model_report_insert( $im_id, $gsm, $message, $status, $error ) {
	global $wpdb;

	$wpdb->insert(
		$wpdb->prefix . 'imn_reports',
		[ 
			'im_id' => $im_id,
			'gsm' => $gsm,
			'message' => $message,
			'status' => $status,
			'error_msg' => $error,
			'created_at' => current_time( 'mysql', 1 )
		],
		[ '%d', '%s', '%s', '%s', '%s', '%s' ]
	);
}