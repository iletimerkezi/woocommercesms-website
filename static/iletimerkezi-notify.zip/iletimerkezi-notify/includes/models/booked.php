<?php
function imn_model_booked_get_calendars() {

	$args = [ 
		'taxonomy' => 'booked_custom_calendars',
		'hide_empty' => false,
	];

	$term_query = new WP_Term_Query( $args );

	if ( empty( $term_query->terms ) ) {
		return [];
	}

	return $term_query->terms;
}