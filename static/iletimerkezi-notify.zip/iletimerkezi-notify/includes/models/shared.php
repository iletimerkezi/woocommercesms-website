<?php

function imn_model_shared_insert( $id, $type, $val ) {
	global $wpdb;

	$wpdb->insert( $wpdb->prefix . 'imn_shared', [ 
		'plugin_id' => $id,
		'plugin_type' => $type,
		'plugin_val' => $val
	] );
}

function imn_model_shared_get( $id, $type ) {
	global $wpdb;

	$shared = $wpdb->get_row(
		$wpdb->prepare( "SELECT * FROM {$wpdb->prefix}imn_shared WHERE plugin_id = %d AND plugin_type = %s", $id, $type )
	);

	if ( $shared ) {
		return $shared->plugin_val;
	}

	return false;
}