<?php

if ( ! class_exists( 'WP_List_Table' ) ) {
	require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

class IMN_Table_Logs extends WP_List_Table {

	public function __construct() {
		parent::__construct( [ 
			'singular' => __( 'Log', 'iletimerkezi-notify' ),
			'plural' => __( 'Logs', 'iletimerkezi-notify' ),
			'ajax' => false,
		] );
	}

	public function get_columns() {
		return [ 
			'id' => __( 'ID', 'iletimerkezi-notify' ),
			'level' => __( 'Level', 'iletimerkezi-notify' ),
			'message' => __( 'Message', 'iletimerkezi-notify' ),
			'created_at' => __( 'Created At', 'iletimerkezi-notify' )
		];
	}

	function column_default( $item, $column_name ) {
		return isset( $item->$column_name ) ? $item->$column_name : '';
	}

	function prepare_items() {
		global $wpdb;

		$columns = $this->get_columns();
		$hidden = [];
		$sortable = $this->get_sortable_columns();
		$this->_column_headers = [ $columns, $hidden, $sortable ];

		$per_page = 50;
		$current_page = $this->get_pagenum();
		$table_name = $wpdb->prefix . 'imn_logs';

		$total_items = $wpdb->get_var( "SELECT COUNT(*) FROM {$table_name}" );
		$this->set_pagination_args( [ 
			'total_items' => $total_items,
			'per_page' => $per_page
		] );

		$offset = ( $current_page - 1 ) * $per_page;
		$this->items = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table_name} ORDER BY id DESC LIMIT %d OFFSET %d", $per_page, $offset ) );
	}
}

function imn_model_log_insert( $level, $message ) {
	global $wpdb;

	$wpdb->insert( $wpdb->prefix . 'imn_logs', [ 
		'level' => $level,
		'message' => $message,
		'created_at' => current_time( 'mysql' )
	] );
}