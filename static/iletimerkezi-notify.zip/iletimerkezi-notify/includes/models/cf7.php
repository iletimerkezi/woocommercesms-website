<?php
function imn_model_cf7_get_form_tags( $form_id ) {
	$form = wpcf7_contact_form( $form_id );
	$tags = $form->scan_form_tags();

	return array_map( function ($tag) {
		return [ 
			'name' => $tag['name'],
			'type' => $tag['type'],
			'options' => $tag['options']
		];
	}, $tags );
}

function imn_model_cf7_get_form_data() {
	$forms = get_posts( array(
		'post_type' => 'wpcf7_contact_form',
		'numberposts' => -1
	) );

	$forms = array_map( function ($form) {
		return [ 
			'id' => $form->ID,
			'title' => $form->post_title,
			'shortcode' => '[contact-form-7 id="' . $form->ID . '" title="' . $form->post_title . '"]',
			'tags' => imn_model_cf7_get_form_tags( $form->ID )
		];
	}, $forms );

	return $forms;
}