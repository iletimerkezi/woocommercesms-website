<?php
/**
 * Plugin Name: iletimerkezi-notify
 * Plugin URI: https://www.woocommercesms.com/
 * Description: Wordpress SMS plugin, play nice with woocommerce, contact form 7 and others.
 * Version: 1.0.0
 * Author: İletimerkezi
 * Domain Path: /languages/
 * Author URI: https://www.iletimerkezi.com/
 * License: GPL-3.0-or-later
 * Text Domain: iletimerkezi-notify
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
require_once( __DIR__ . '/includes/constants.php' );
require_once( __DIR__ . '/install.php' );
require_once( __DIR__ . '/includes/constants.php' );
require_once( __DIR__ . '/includes/api-iletimerkezi.php' );
require_once( __DIR__ . '/includes/logger.php' );
require_once( __DIR__ . '/includes/callbacks/integration.php' );
require_once( __DIR__ . '/includes/callbacks/shared.php' );
require_once( __DIR__ . '/includes/callbacks/woocommerce.php' );
require_once( __DIR__ . '/includes/callbacks/cf7.php' );
require_once( __DIR__ . '/includes/models/integration.php' );
require_once( __DIR__ . '/includes/models/log.php' );
require_once( __DIR__ . '/includes/models/report.php' );
require_once( __DIR__ . '/includes/views/admin.php' );
require_once( __DIR__ . '/includes/views/general.php' );
require_once( __DIR__ . '/includes/views/integrations.php' );
require_once( __DIR__ . '/includes/views/logs.php' );
require_once( __DIR__ . '/includes/views/reports.php' );
require_once( __DIR__ . '/includes/views/select-country.php' );
require_once( __DIR__ . '/includes/views/woocommerce.php' );
require_once( __DIR__ . '/includes/views/cf7.php' );
try {
	include_once( __DIR__ . '/includes/user-functions.php' );
} catch (Exception $e) {
	imn_log( 'user-functions.php', $e->getMessage() );
}

register_activation_hook( __FILE__, 'imn_install' );

add_action( 'admin_menu', 'imn_view_admin_menu' );
add_action( 'admin_init', 'imn_view_admin_fields_init' );
add_action( 'wp_ajax_imn_webhook', 'imn_api_handle_webhook' );
add_action( 'wp_ajax_nopriv_imn_webhook', 'imn_api_handle_webhook' );

if ( is_plugin_active( 'woocommerce/woocommerce.php' ) ) {
	add_action(
		'woocommerce_order_status_changed',
		'imn_callback_wc_order_status_changed',
		10,
		3
	);
	add_action(
		'woocommerce_checkout_order_processed',
		'imn_callback_wc_new_order_created',
		10,
		3
	);
	add_action(
		'woocommerce_new_customer_note',
		'imn_callback_wc_new_customer_order_note',
		10,
		1
	);
}

if ( is_plugin_active( 'contact-form-7/wp-contact-form-7.php' ) ) {
	add_action(
		'wpcf7_mail_sent',
		'imn_callback_cf7_sms_sent',
		10,
		1
	);
}

imn_callback_integration_register();

function imn_load_textdomain() {
	load_plugin_textdomain(
		'iletimerkezi-notify',
		false,
		dirname( plugin_basename( __FILE__ ) ) . '/languages'
	);
}

add_action( 'plugins_loaded', 'imn_load_textdomain' );