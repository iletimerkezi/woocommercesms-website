<?php
function imn_install() {
	global $wpdb;

	$table_logs = $wpdb->prefix . 'imn_logs';
	$table_reports = $wpdb->prefix . 'imn_reports';
	$table_integration = $wpdb->prefix . 'imn_integrations';
	$charset_collate = $wpdb->get_charset_collate();

	$sql[] = "CREATE TABLE $table_reports (
		`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`im_id` bigint(20) unsigned DEFAULT NULL,
		`gsm` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
		`message` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
		`status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
		`created_at` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
		`updated_at` datetime DEFAULT NULL,
		PRIMARY KEY (`id`)
	  ) $charset_collate;";

	$sql[] = "CREATE TABLE $table_integration (
		`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`hook` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
		`hook_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
		`function_name` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
		`status` tinyint(4) NOT NULL DEFAULT '1',
		`priority` int(11) NOT NULL DEFAULT '10',
		`accepted_args` int(11) NOT NULL DEFAULT '1',
		`created_at` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
		PRIMARY KEY (`id`)
	  ) $charset_collate;";

	$sql[] = "CREATE TABLE $table_logs (
		`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`level` enum('INFO','WARNING','FATAL') COLLATE utf8mb4_unicode_ci NOT NULL,
		`message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
		`created_at` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
		PRIMARY KEY (`id`),
		KEY `level` (`level`)
	  ) $charset_collate;";

	dbDelta( $sql );
}