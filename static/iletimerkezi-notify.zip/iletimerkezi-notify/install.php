<?php
function imn_install() {
	global $wpdb;

	$table_logs = $wpdb->prefix . 'imn_logs';
	$table_shared = $wpdb->prefix . 'imn_shared';
	$table_reports = $wpdb->prefix . 'imn_reports';
	$table_integration = $wpdb->prefix . 'imn_integrations';
	$charset_collate = $wpdb->get_charset_collate();

	$wpdb->query( "DROP TABLE IF EXISTS $table_logs;" );
	$wpdb->query( "DROP TABLE IF EXISTS $table_shared;" );
	$wpdb->query( "DROP TABLE IF EXISTS $table_reports;" );
	$wpdb->query( "DROP TABLE IF EXISTS $table_integration;" );

	$sql[] = "CREATE TABLE $table_reports (
		`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`im_id` bigint(20) unsigned DEFAULT NULL,
		`gsm` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
		`message` varchar(2000) COLLATE utf8mb4_unicode_ci NOT NULL,
		`status` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
		`created_at` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
		`updated_at` datetime DEFAULT NULL,
		PRIMARY KEY (`id`)
	  ) $charset_collate;";

	$sql[] = "CREATE TABLE $table_integration (
		`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`hook` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
		`hook_type` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
		`function_name` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
		`status` tinyint(4) NOT NULL DEFAULT '1',
		`priority` int(11) NOT NULL DEFAULT '10',
		`accepted_args` int(11) NOT NULL DEFAULT '1',
		`created_at` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
		PRIMARY KEY (`id`)
	  ) $charset_collate;";

	$sql[] = "CREATE TABLE $table_logs (
		`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`level` enum('INFO','WARNING','FATAL') COLLATE utf8mb4_unicode_ci NOT NULL,
		`message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
		`created_at` datetime NOT NULL ON UPDATE CURRENT_TIMESTAMP,
		PRIMARY KEY (`id`),
		KEY `level` (`level`)
	  ) $charset_collate;";

	$sql[] = "CREATE TABLE $table_shared (
		`id` int(11) unsigned NOT NULL AUTO_INCREMENT,
		`plugin_id` int(11) NOT NULL,
		`plugin_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
		`plugin_val` text COLLATE utf8mb4_unicode_ci NOT NULL,
		PRIMARY KEY (`id`),
		KEY `plugin_id` (`plugin_id`),
		KEY `plugin_type` (`plugin_type`),
		KEY `plugin_type_id` (`plugin_type`,`plugin_id`)
	  ) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";

	dbDelta( $sql );
}